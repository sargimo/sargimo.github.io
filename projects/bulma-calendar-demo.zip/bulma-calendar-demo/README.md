# Bulma Calendar
A little demo of how to use Bulma Calendar to get the number of days between two dates.

## Installation
Run ````npm i````